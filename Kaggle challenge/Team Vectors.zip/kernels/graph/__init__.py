from kenels.graph.randomwalk import RandomWalk
from kenels.graph.allgraphlets import All34Graphlets
from kenels.graph.shortestpath import ShortestPath